/*
 * GarageBand - intentionally blank PS4 homebrew application.
 * The process stays alive until the user closes the app.
 */
#include <unistd.h>

int main(void)
{
    for (;;) {
        sleep(1);
    }
    return 0;
}
